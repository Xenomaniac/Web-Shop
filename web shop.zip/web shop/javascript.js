document.getElementById('category').addEventListener('change', function() {
    const category = this.value;
    const products = document.querySelectorAll('.product');
    
    products.forEach(product => {
        if (category === 'all' || product.classList.contains(category)) {
            product.style.display = 'block';
        } else {
            product.style.display = 'none';
        }
    });
});

document.addEventListener('mousemove', function(e) {
    const laser = document.createElement('div');
    laser.className = 'laser';
    laser.style.left = `${e.pageX}px`;
    laser.style.top = `${e.pageY}px`;
    document.body.appendChild(laser);
    setTimeout(() => {
        laser.remove();
    }, 1000);
});

const cart = [];
const cartCount = document.getElementById('cart-count');

document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', function() {
        const product = this.parentElement;
        const productName = product.querySelector('h3').innerText;
        const productPrice = product.querySelector('p').innerText;
        
        cart.push({ name: productName, price: productPrice });
        cartCount.innerText = cart.length;
    });
});
